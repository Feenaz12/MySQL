package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class StoreApplication implements CommandLineRunner {

	public static void main(String[] args) {
		
		SpringApplication.run(StoreApplication.class, args);
		
	}
	@Autowired
	ProductRepository productRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Override
	public void run(String... args) throws Exception
	{
		
		
		//Product Details
		/*ArrayList<Product> prolist=new ArrayList<Product>();
		Product pro1=new Product();
		pro1.setProName("table");
		pro1.setPrice(25000.00);
		Product pro2=new Product();
		pro2.setProName("pencil");
		pro2.setPrice(20.0);
		Product pro3=new Product();
		pro3.setProName("top");
		pro3.setPrice(5.00);
		prolist.add(pro1);
		prolist.add(pro2);
		prolist.add(pro3);
		productRepository.saveAll(prolist);
		System.out.println("These are list of products");
		
		
		//Customer Details
				ArrayList<Customer> cuslist=new ArrayList<Customer>();
				Customer cus1=new Customer();
				cus1.setCusName("Rohan");
				cus1.setAddress("hubli");
				Customer cus2=new Customer();
				cus2.setCusName("mohan");
				cus2.setAddress("delhi");
				Customer cus3=new Customer();
				cus3.setCusName("sohan");
				cus3.setAddress("pune");
				cuslist.add(cus1);
				cuslist.add(cus2);
				cuslist.add(cus3);
				customerRepository.saveAll(cuslist);
				System.out.println("These are list of Customers");*/
				
		
		
		
		//update
		/*Optional<Product> prod=productRepository.findById(1);
		Product p=prod.get();
		p.setPrice(20000);
		productRepository.save(p);
		System.out.println("Product Updated!");*/
		
		Optional<Customer> cust=customerRepository.findById(13);
		Customer c=cust.get();
		c.setAddress("Bangalore");
		customerRepository.save(c);
		System.out.println("Customer Address Updated!");
		
		
		//get all details
		/*List<Product> prolist=productRepository.findAll();
		for(Product p1:prolist) {
			System.out.println(p1);
		}
			
			List<Customer> cuslist=customerRepository.findAll();
		for(Customer c1:cuslist) {
			System.out.println(c1);
		}8*/		
		
		
		//delete
		/*ProductRepository.deleteById(3);
		System.out.println("Deleted product successfully!");*/
				
		/*CustomerRepository.deleteById(3);
		System.out.println("Deleted customer successfully!");*/
		
		//deleteAll
		/*customerRepository.deleteAll();
		System.out.println(" ALL Deleted successfully!");
		productRepository.deleteAll();
		System.out.println(" ALL Deleted successfully!");*/
			
		}
		
		
		
	}


